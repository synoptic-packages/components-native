#!/usr/bin/env bash
#
# Build @wallet/provider, pack it as a .tgz, and distribute the tarball
# into each sibling frontend that consumes it. Two modes:
#
#   ./scripts/local-install.sh            -> build + pack + copy .tgz only.
#                                            Print one-time setup instructions.
#   ./scripts/local-install.sh --install  -> build + pack + copy + run
#                                            `yarn add file:./.packages/...` in
#                                            each consumer, refreshing the dep.
#
# Discovery: any sibling project whose package.json mentions `@wallet/provider`
# is treated as a consumer.
#
# The tarball keeps its versioned npm-pack filename
# (wallet-provider-<version>.tgz). Yarn v1 caches `file:` tarballs by
# spec, so reusing a fixed filename silently reinstalls stale builds — bump
# the package version before distributing.

set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
WORKSPACE="$(cd "$ROOT/.." && pwd)"
INSTALL=false

while [[ $# -gt 0 ]]; do
	case "$1" in
		--install|-i)
			INSTALL=true
			shift
			;;
		-h|--help)
			sed -n '2,15p' "$0"
			exit 0
			;;
		*)
			echo "Unknown arg: $1" >&2
			exit 1
			;;
	esac
done

echo "==> Building @wallet/provider"
cd "$ROOT"
yarn build

echo "==> Packing"
mkdir -p packs
rm -f packs/*.tgz
TGZ_NAME=$(npm pack --pack-destination ./packs --silent | tail -n1)
TGZ_PATH="$ROOT/packs/$TGZ_NAME"
echo "    $TGZ_PATH"

CONSUMERS=()
for dir in "$WORKSPACE"/*/; do
	project="$(basename "$dir")"
	[[ "$project" == "provider" ]] && continue
	[[ -f "$dir/package.json" ]] || continue
	if grep -q '"@wallet/provider"' "$dir/package.json"; then
		CONSUMERS+=("$dir")
	fi
done

if [[ ${#CONSUMERS[@]} -eq 0 ]]; then
	echo "No consumers found."
	exit 0
fi

echo "==> Distributing to ${#CONSUMERS[@]} consumer(s)"
for dir in "${CONSUMERS[@]}"; do
	project="$(basename "$dir")"
	dest_dir="${dir}.packages"
	mkdir -p "$dest_dir"
	rm -f "$dest_dir"/wallet-provider*.tgz
	dest_path="$dest_dir/$TGZ_NAME"
	cp "$TGZ_PATH" "$dest_path"
	echo "    $project/.packages/$TGZ_NAME"
	# NOTE: the tgz is deliberately TRACKED in git (origin/master carries it) so the consumers'
	# `file:./.packages/wallet-provider-<ver>.tgz` dependency resolves on CI and fresh checkouts, which do
	# not run this script. Do not gitignore `.packages/` — doing so breaks those installs.
done

if $INSTALL; then
	echo "==> Installing in each consumer"
	for dir in "${CONSUMERS[@]}"; do
		project="$(basename "$dir")"
		echo "    yarn add file:./.packages/$TGZ_NAME   ($project)"
		(
			cd "$dir"
			yarn cache clean @wallet/provider >/dev/null 2>&1 || true
			yarn add "file:./.packages/$TGZ_NAME" --silent >/dev/null
		)
	done
	echo "==> Done. Restart Metro / dev server in each consumer."
else
	echo ""
	echo "==> Next steps"
	echo "  First time per consumer (persists in package.json):"
	echo "      cd <consumer> && yarn add file:./.packages/$TGZ_NAME"
	echo "  Subsequent rebuilds: bump the version, then rerun with --install"
	echo "      ./scripts/local-install.sh --install"
fi
