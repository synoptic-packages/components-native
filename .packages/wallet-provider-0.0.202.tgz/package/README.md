# wallet-provider

Shared Parse-native wallet client, React context, domain services, and compatibility provider for wallet frontend applications — web (React) and native (Expo / React Native).

## Parse-native boundary

Version `0.0.43` provides the shared wallet backend boundary used by mobile and web:

- `createWalletParseClient` accepts an injected platform Parse namespace, initializes it once, owns the Parse session, carries the configured Parse Server client key as `X-Parse-Client-Key`, and normalizes Parse error `209` as `ParseSessionInvalidError`.
- `WalletParseProvider` and `useWalletParse` expose one client and one stable set of domain services to a React tree.
- `CloudFunctionMap` types the backend's camelCase Cloud Function parameters and results.
- `ClientReadableClassName` permits direct queries only for the four global catalogs and the backend-audited session-scoped classes; `LiveQueryClassName` permits `Wallet`, `WalletHold`, `WalletTransaction`, `EventOrder`, `Notification`, `Asset`, `AssetWallet`, `AssetTransaction`, the Yaya/Vya participant classes `MobilityJob`, `MobilityJobLocation`, `MobilityJobMessage`, `MobilityOffer`, `MerchantOrder`, and — spec 055 — the exact-owner channels `UserProfile` (the user's own surface choice + profile changes) and `DriverProfile` (the driver's own go-online/offline and suspend/restore).
- `useParseAuth`, `useParseAccounts`, `useParseService`, `useParseWallet`, `useParseEvents`, `useParseMerchants`, `useParseEats`, `useParseFamily`, `useParseAssets`, `useParseSplits`, `useParseNotifications`, and `useParseMedia` expose backend-driven operations without Axios or REST wrappers.
- Money, permission, account, order, merchant, family, asset, split, and media mutations remain exact Cloud Function calls. The client never calculates server-owned values.
- `createWalletEndpointResolver` (with `fetchWalletAppConfig`, `walletAppConfigFrom`, `resolveWalletEnvironmentName`, `walletApiBasePathFrom`, `walletEndpointHostIsAllowed`) implements server-owned mobile endpoint discovery: each tenant apex serves `/.well-known/wallet/app-config.json`, the document maps app build numbers to one of exactly two environment blocks — `production` (`/v2/*` on the tenant apex) or `development` (the `*-services-dev.infomentor.cc` tunnel, served at the origin root). `WalletEndpointEnvironmentName` is the shared union every other wallet repository imports, and `WALLET_ENDPOINT_ENVIRONMENT_NAMES` is its runtime list, asserted to have exactly two members so a third tier cannot silently reappear. Clients validate every origin against a baked allowlist (HTTPS; the build's own tenant apex or `*.infomentor.cc`), cache the last-known-good document through an injected storage, and fall back to the baked build-time block. A document with any disallowed origin is rejected whole. `refresh()` fetches with a short timeout and stores for the next launch; `resolve()` never touches the network.

The package still exports the old Redux, Axios/OpenAPI, JWT, and WebSocket APIs so existing consumers compile during migration. Those exports are migration-only for the wallet program. New wallet/mobile code must use the Parse-native boundary.

## Platform setup

The package deliberately does not bundle `parse`; each platform injects the correct SDK entry point. Consumers should pin `parse@8.6.0` to the backend line. Every `WalletParseProvider` must also declare the one closed product Service: `yaya`.

## Installation

This package is consumed as **`@wallet/provider`**. Local wallet development installs the checked-in package artifact; publishing can be re-enabled once the wallet package scope and registry are finalized.

### 1. Configure your `.npmrc`

In the consuming project's root, add:

```
@wallet:registry=https://npm.pkg.github.com
//npm.pkg.github.com/:_authToken=${NODE_AUTH_TOKEN}
always-auth=true
```

For a private registry install, export a PAT with `read:packages` scope (https://github.com/settings/tokens):

```bash
export NODE_AUTH_TOKEN=ghp_xxx
```

In CI, set `NODE_AUTH_TOKEN` to `${{ secrets.GITHUB_TOKEN }}`.

### 2. Install

```bash
yarn add @wallet/provider@0.0.43 parse@8.6.0
```

### Required peer dependencies

```json
{
	"react": ">=17",
	"react-dom": ">=17"
}
```

### Native (Expo / React Native)

```bash
yarn expo install expo-secure-store
```

## Parse quick start — web

```tsx
import Parse from 'parse'
import { WalletParseProvider, createWalletParseClient } from '@wallet/provider'

const client = createWalletParseClient({
	parse: Parse,
	applicationId: 'wallet',
	clientKey: 'wallet-client-key',
	serverURL: 'https://wallet.example.com/api',
})

function App() {
	return (
		<WalletParseProvider client={client} serviceSlug={`yaya`}>
			<YourApp />
		</WalletParseProvider>
	)
}
```

## Parse quick start — Expo / React Native

```tsx
import Parse from 'parse/react-native.js'
import { WalletParseProvider, createWalletParseClient } from '@wallet/provider'
import { parseSecureStorage } from './parseSecureStorage'

const client = createWalletParseClient({
	parse: Parse,
	applicationId: 'wallet',
	clientKey: 'wallet-client-key',
	serverURL: 'https://wallet-dev.example.com/api',
	asyncStorage: parseSecureStorage,
})

function App() {
	return (
		<WalletParseProvider client={client} serviceSlug={`yaya`}>
			<YourApp />
		</WalletParseProvider>
	)
}
```

`serverURL` is the public backend origin plus `/api`. `clientKey` is the backend-configured public Parse client key and is sent by the SDK request boundary as `X-Parse-Client-Key`; it is not the master key, JavaScript key, session token, or SDK installation id. Expo/device builds must use a mobile-reachable HTTPS origin, not `localhost` or `127.0.0.*`. `parseSecureStorage` must implement the exported `ParseAsyncStorage` string contract with device-bound encrypted storage. Do not persist Parse bearer credentials in plain AsyncStorage or backup-restorable storage.

## Session and bootstrap

Hosted backend auth hands mobile a short-lived code. Exchange it once, establish the SDK session with `Parse.User.become`, and bootstrap backend truth:

Build the hosted mobile URL with `buildAuthUrl({ authBase, service: 'yaya', client: 'rn' })`. This preserves the canonical service identity and produces `/auth/login/?service=yaya&client=rn`; the backend still owns every credential page.

```tsx
import { useParseAuth } from '@wallet/provider'

function SessionBoundary({ code }: { code: string }) {
	const auth = useParseAuth()

	const start = async () => {
		const bootstrap = await auth.acceptHandoff(code)
		return bootstrap.profile.activeAccount
	}

	return null
}
```

`WalletParseProvider` runs `hydrate()` once by default. `useParseAuth()` exposes `isHydrated`, `isAuthenticated`, `isLoading`, `user`, `bootstrap`, and `error`; route guards and product containers consume this state instead of maintaining another session/bootstrap store. `isAuthenticated` becomes true only after the authoritative `auth_bootstrap` succeeds. A restored SDK user with a failed bootstrap remains available in `user` for a fail-closed retry/logout boundary but may not enter product routes. `acceptHandoff(code)` becomes the returned Parse session and updates the same state, and `switchAccount(accountId)` calls `auth_setActiveAccount` and reboots the projection; either bootstrap failure clears the prior projection instead of exposing stale account state. Auth transitions are serialized under a monotonic epoch, so a slow hydrate, bootstrap, handoff, account switch, or profile refresh cannot commit after a newer transition or resurrect state after logout. `isLoading` remains true until every in-flight transition has settled.

`logout()` invalidates React state before waiting for serialized remote revocation and calls `Parse.User.logOut()` without explicit token options so the SDK removes its persisted React Native current-user record. The local state stays cleared even if the remote revoke fails. A direct SDK operation or a later LiveQuery `error` event that reports Parse code `209` runs the same idempotent persisted-user invalidation path. Do not replace this with the SDK's token-only logout branch: that branch sends the remote request but can leave the SDK current-user record behind.

Pass the product's required closed `serviceSlug` (`yaya`) to
`WalletParseProvider`. The provider resolves that active Service once and rejects a bootstrap unless
its profile, every returned account, membership, and wallet belong to the same Service projection.
A mismatch logs out and clears the persisted SDK user. The factory also supplies that slug to every
anonymous-capable catalog/configuration call; authenticated authority still comes only from the
service bound to the Parse session, and the backend rejects a mismatched supplied slug.

`mobileNumberFromFieldPhone(value)` is the only shared mapper from the established frontend `FieldPhone` value to Parse's exact `{ countryCode, national, international }` contract. It returns the required all-empty structure for an untouched field and rejects partial, invalid, country-mismatched, or E.164-mismatched values. Forms must not forward `raw`/`phoneNumberInternational` keys or reshape phone data locally.

Do not call `currentUser.fetch()`: `_User` query access is denied. Use `currentAsync()` for the persisted SDK user and `bootstrapSession()` or `refreshBootstrap()` for the product projection. Set `autoHydrate={false}` only in tests or a shell that deliberately controls the first `hydrate()` call.

## Domain hooks

| Hook                    | Backend-owned operations                                                                                                                                                                          |
| ----------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `useParseAuth`          | reactive session/bootstrap state, handoff acceptance, hydration, active-account switch, profile update, logout                                                                                    |
| `useParseService`       | service resolution by supported slug/domain                                                                                                                                                       |
| `useParseAccounts`      | accounts, memberships, invitations                                                                                                                                                                |
| `useParseWallet`        | config, payment methods, dashboard, deposit, withdrawal, transfer, refund, realtime                                                                                                               |
| `useParseEvents`        | event feed/detail/management, tickets, server-serialized order history, order realtime                                                                                                            |
| `useParseMerchants`     | in-person POS: profiles, dashboard, transactions, items, purchases, payments and charges                                                                                                          |
| `useParseEats`          | Vya remote merchant orders: storefront/catalog discovery, recipient context, quote, place, audience-scoped order reads, the store board's per-transition commands, settlements and order realtime |
| `useParseFamily`        | sub-wallets, child capability view, policies, transfer requests                                                                                                                                   |
| `useParseAssets`        | service catalog, quote, portfolio, buy/sell/transfer, server-serialized transactions and realtime                                                                                                 |
| `useParseSplits`        | list, request, pay, decline                                                                                                                                                                       |
| `useParseNotifications` | owner query/update, mark-all-read and realtime                                                                                                                                                    |
| `useParseMedia`         | upload, list, guarded URL and delete                                                                                                                                                              |

All idempotent operations accept an optional `idempotencyKey`. When omitted, the shared service creates one key and uses that same key for the complete Cloud Function invocation. Callers that intentionally retry across invocations must retain and resupply their key.

Split results include the parent order's authoritative `currencyCode` on list, request, pay, decline, and nested order-history responses. Consumers must display that value and must not assume a fallback currency.

## Composition with the legacy root provider

The Parse provider is independent and can be nested inside the existing root while a consumer migrates:

```tsx
<WalletProvider {...legacyProps}>
	<WalletParseProvider client={client} serviceSlug={`yaya`}>
		<App />
	</WalletParseProvider>
</WalletProvider>
```

When the legacy root provider remains mounted during migration, pass the same backend-configured public Parse `clientKey`
used by `WalletParseProvider` so its compatibility bootstrap and backend client send `X-Parse-Client-Key`. Do not use the
legacy provider's `backend` context, `useBackend`, generated OpenAPI types, or WebSocket hooks for new wallet work.

Non-React code and focused tests can use `createParseServices(client, serviceSlug)` or `useWalletParse().services` as an imperative facade. The required closed slug prevents unscoped public product reads. `services.auth` performs backend calls but does not own React state; routed React code uses `useParseAuth()` so hydration, invalidation, account switching, and logout remain synchronized.

## Legacy API reference (migration-only)

The sections below describe compatibility exports that predate the Parse-native wallet boundary. They are retained only for untouched consumers and must not be extended for wallet/mobile work.

## Recommended legacy app wiring

Initialize the package in this order:

1. Configure platform storage. Native apps must call `setStorageEngine(AsyncStorage)` before any code reads from `StorageAsync`.
2. Create the store with `createWalletStore({ slug, storage })`.
3. Wrap the app in `<WalletProvider store={store} persistor={persistor} slug={slug}>`.
4. Hydrate auth state from an app shell or auth boundary by calling `useAuth().hydrate()`.
5. Enable realtime updates with `useWalletWebSocket()` after auth state is available.

This ordering keeps redux-persist, provider IID generation, backend auth, and websocket connection state aligned across web and native projects.

## Legacy public API map

| Area             | Import                                                                            | Use When                                                                 |
| ---------------- | --------------------------------------------------------------------------------- | ------------------------------------------------------------------------ |
| Provider/context | `WalletProvider`, `useWalletRoot`                                                 | Root app setup and access to resolved API/media/IID/backend context      |
| Store            | `createWalletStore`, `resetApp`                                                   | App startup, tenant-scoped persistence, full state reset                 |
| Store actions    | `setCredentials`, `setTenant`, `setWallet`, etc.                                  | Reducer updates from app workflows or backend responses                  |
| Auth             | `useAuth`                                                                         | Login, logout, hydration, token refresh, profile/account refresh         |
| Backend          | `useBackend`, `createBackendClient`                                               | Authenticated HTTP requests from React or non-React code                 |
| WebSocket        | `useWebSocket`, `useWalletWebSocket`                                              | Realtime session/profile/ehailing updates                                |
| Data hooks       | `useCountry`, `useCurrency`, `useCrypto`, `useLanguage`                           | Select options and lookup helpers from bundled or supplied seed data     |
| KYC              | `useKyc`, `computeKycFlags`                                                       | **Retired Django-era route guards — do not use in new work** (see below) |
| Utilities        | `StorageAsync`, `decodeJwtUnsafe`, `resolveApiUrl`, phone/string/currency helpers | Shared cross-platform behavior and formatting                            |
| Constants        | `countries`, `currencies`, `cryptos`, `languages`                                 | Static seed data for forms, selectors, and fallback UI                   |
| Backend types    | `backend-models`, `backend-type-helpers` generated files                          | Typed backend payloads and OpenAPI path helpers                          |

## Legacy provider

### `WalletProvider`

| Prop           | Type                            | Default               | Description                                                                                      |
| -------------- | ------------------------------- | --------------------- | ------------------------------------------------------------------------------------------------ |
| `slug`         | `string`                        | **required**          | Product slug. The legacy per-slug dev host builder is gone; pass `apiUrl` explicitly             |
| `environment`  | `'development' \| 'production'` | `'production'`        | Adds `-dev` suffix to API URL when `'development'`                                               |
| `apiUrl`       | `string`                        | derived from slug/env | Explicit backend base URL override                                                               |
| `store`        | `Store`                         | **required**          | Redux store from `createWalletStore()`                                                           |
| `persistor`    | `Persistor`                     | `undefined`           | redux-persist persistor                                                                          |
| `clientKey`    | `string`                        | `undefined`           | Public Parse client key sent as `X-Parse-Client-Key` when the backend enforces client-key access |
| `mediaUrl`     | `string`                        | `''`                  | Media server URL                                                                                 |
| `cookieDomain` | `string`                        | current host          | Cookie domain for shared web credentials; pass `''` to disable cookies                           |
| `isStorybook`  | `boolean`                       | env-derived           | Explicit Storybook mode override                                                                 |
| `loading`      | `ReactNode`                     | `null`                | PersistGate loading component                                                                    |
| `storageKey`   | `string`                        | `'installation_id'`   | Key for IID storage                                                                              |
| `generateUUID` | `() => string`                  | `crypto.randomUUID()` | Native: inject `Crypto.randomUUID` from expo-crypto                                              |

The provider automatically:

- Resolves the API URL from slug/env
- Creates and initializes the backend client
- Stores the current installation ID (IID) state for auth and request headers
- Stores bootstrap data when provider-backed backend calls return it
- Detects platform (`'web'` / `'native'`)

### `useWalletRoot()`

```ts
const {
	slug, // string
	platform, // 'web' | 'native'
	apiUrl, // resolved backend URL
	mediaUrl, // string
	iid, // string | null (installation ID)
	isRefreshing, // boolean
	setRefreshing, // (value: boolean) => void
	isLoading, // boolean
	setLoading, // (value: boolean) => void
	isStorybook, // boolean
	bootstrap, // any | null (bootstrap response)
	backend, // BackendClient | null (pre-initialized)
} = useWalletRoot()
```

## Store

### `createWalletStore(config)`

Creates a pre-configured Redux store with **20 built-in reducers**.

| Option                   | Type                      | Default                     | Description                                                                   |
| ------------------------ | ------------------------- | --------------------------- | ----------------------------------------------------------------------------- |
| `slug`                   | `string`                  | **required**                | Tenant slug for persist key namespacing                                       |
| `slices`                 | `Record<string, Reducer>` | `{}`                        | Extra slices merged into the store                                            |
| `storage`                | `any`                     | **required**                | Storage engine (`redux-persist/lib/storage` on web, `AsyncStorage` on native) |
| `rootPersistWhitelist`   | `string[]`                | `['config', 'theme']`       | Root persist whitelist                                                        |
| `devTools`               | `boolean`                 | `NODE_ENV !== 'production'` | Enable Redux DevTools                                                         |
| `logger`                 | `{ createLogger }`        | `undefined`                 | redux-logger (consumer provides)                                              |
| `loggerStateTransformer` | `(state) => any`          | `undefined`                 | Transform state before logging                                                |
| `middleware`             | `Middleware[]`            | `[]`                        | Additional middleware                                                         |

Returns `{ store, persistor }`.

#### Built-in Reducers (20)

| Key            | Slice                                         | Seeded from             | Persisted                    |
| -------------- | --------------------------------------------- | ----------------------- | ---------------------------- |
| `user`         | Auth credentials, user object, hydration flag | —                       | —                            |
| `accounts`     | Account list + selected account               | —                       | `account` (separate persist) |
| `cards`        | Card list                                     | —                       | —                            |
| `config`       | Geo, period span, loading/uploading state     | —                       | ✔                            |
| `countries`    | Country list                                  | bundled countries JSON  | —                            |
| `crypto`       | Cryptocurrency list                           | bundled cryptos JSON    | —                            |
| `currencies`   | Currency list                                 | bundled currencies JSON | —                            |
| `dictionaries` | Dictionary list                               | —                       | —                            |
| `fx`           | USD-based FX rate map                         | —                       | —                            |
| `invitations`  | Sent/received group invitations               | —                       | —                            |
| `kgr`          | KGR market data                               | —                       | —                            |
| `kgrWallet`    | KGR wallet entries                            | —                       | —                            |
| `kyc`          | KYC profile state                             | —                       | —                            |
| `languages`    | Language list                                 | bundled languages JSON  | —                            |
| `roles`        | Selected role                                 | —                       | —                            |
| `tenant`       | Tenant / service config                       | —                       | —                            |
| `theme`        | Light / dark mode                             | —                       | ✔                            |
| `timezones`    | Timezone list                                 | —                       | —                            |
| `wallet`       | Wallet object                                 | —                       | —                            |
| `websocket`    | Ehailing event log                            | —                       | —                            |

#### Store Action Exports

```ts
import {
	// user
	setCredentials,
	clearCredentials,
	setAuthHydrated,
	clearAuthState,
	setUser,
	setUserAuthErrorMessage,
	setUserAuthSuccessMessage,
	setUserScopeLoading,
	setUserProfilePicture,
	setLoginPhase1State,
	// config
	setGeo,
	setPeriodSpan,
	setInstallationId,
	setNotificationToken,
	setNotificationTokenExpo,
	setDoNotDisturb,
	setGlobalLoadingState,
	setGlobalUploadingState,
	// theme
	setThemeMode,
	toggleThemeMode,
	// tenant
	setTenant,
	setTenantLoading,
	setTenantError,
	clearTenant,
	fetchTenantStart,
	fetchTenantSuccess,
	fetchTenantFailure,
	// countries
	setCountries,
	fetchCountriesStart,
	fetchCountriesSuccess,
	fetchCountriesFailure,
	// currencies
	setCurrencies,
	fetchCurrenciesStart,
	fetchCurrenciesSuccess,
	fetchCurrenciesFailure,
	// crypto
	setCryptos,
	fetchCryptosStart,
	fetchCryptosSuccess,
	fetchCryptosFailure,
	// languages
	setLanguages,
	fetchLanguagesStart,
	fetchLanguagesSuccess,
	fetchLanguagesFailure,
	// timezones
	setTimezones,
	fetchTimezonesStart,
	fetchTimezonesSuccess,
	fetchTimezonesFailure,
	// dictionaries
	setDictionaries,
	fetchDictionariesStart,
	fetchDictionariesSuccess,
	fetchDictionariesFailure,
	// accounts
	setAccounts,
	setAccount,
	fetchAccountsStart,
	fetchAccountsSuccess,
	fetchAccountsFailure,
	// cards
	setCards,
	fetchCardsStart,
	fetchCardsSuccess,
	fetchCardsFailure,
	// wallet
	setWallet,
	fetchWalletStart,
	fetchWalletSuccess,
	fetchWalletFailure,
	// kyc
	setKycProfile,
	clearKycProfile,
	fetchKycProfileStart,
	fetchKycProfileSuccess,
	fetchKycProfileFailure,
	// fx
	setFx,
	// kgr
	setKgrMarkets,
	fetchKgrMarketsStart,
	fetchKgrMarketsSuccess,
	fetchKgrMarketsFailure,
	// kgr wallet
	setKgrWallet,
	fetchKgrWalletStart,
	fetchKgrWalletSuccess,
	fetchKgrWalletFailure,
	// invitations
	setSentInvitations,
	setReceivedInvitations,
	setSentLoading,
	setReceivedLoading,
	setInvitationsError,
	removeSentInvitation,
	removeReceivedInvitation,
	updateSentInvitation,
	clearInvitations,
	// roles
	setSelectedRole,
	clearSelectedRole,
	// websocket
	ehailingEventReceived,
	// global
	resetApp,
} from '@wallet/provider'
```

### `resetApp`

```ts
dispatch(resetApp()) // wipes all state
```

### Persistence Keys

`createWalletStore()` prefixes persisted keys with the tenant slug:

- `${slug}:root` stores the root whitelist, defaulting to `config` and `theme`.
- `${slug}:accounts` stores the selected `accounts.account` value separately.
- Auth credentials are stored by `BackendClient`/`StorageAsync` under `auth-credentials`.
- The installation ID is stored under `installation_id` by default.

Use tenant-specific slugs consistently across provider and store creation. Changing the slug changes the persistence namespace and causes the app to behave like a fresh tenant install.

### Adding App Slices

Consumer apps can merge their own reducers into the same store:

```ts
const { store, persistor } = createWalletStore({
	slug: 'synoptic',
	storage,
	slices: {
		appSettings: appSettingsReducer,
	},
	rootPersistWhitelist: ['config', 'theme', 'appSettings'],
})
```

Extra slices are added after built-in provider slices. Avoid reusing built-in keys unless you intentionally want to replace provider behavior.

## Backend Client

The `backend` object from `useWalletRoot()` is a pre-initialized `BackendClient` with the resolved API URL, auth interceptors, token rotation, and installation ID header. No manual setup needed.

```ts
const { backend } = useWalletRoot()

// HTTP methods (auto-authenticated)
await backend.get('/api/items/')
await backend.post('/api/items/', { name: 'foo' })
await backend.patch('/api/items/1/', { name: 'bar' })
await backend.put('/api/items/1/', { name: 'baz' })
await backend.delete('/api/items/1/')
await backend.request('GET', '/api/custom/')

// Profile
await backend.fetchCurrentUser()
await backend.fetchBootstrap()

// Account
await backend.fetchAccounts()

// Credential storage (uses StorageAsync)
await backend.writeAuthCredentials({ accessToken, refreshToken })
const creds = await backend.readAuthCredentials()
await backend.clearAuthCredentials()

// OTP phase 1 persistence
await backend.writeLoginPhase1State({ username, password, jwtToken, intent })
const phase1 = await backend.readLoginPhase1State()
await backend.clearLoginPhase1State()

// Credential preference
await backend.writeAuthCredentialPreference('email')
const pref = await backend.readAuthCredentialPreference()

// Utilities
backend.isTokenExpired(token, 30)
backend.instance // raw AxiosInstance
```

Use `useAuth()` for login, logout, signup, password recovery, initial password change, and IID management. The backend client keeps credential storage and token refresh primitives for provider internals and standalone integrations.

### Standalone `createBackendClient(config)`

For use outside the provider:

```ts
import { createBackendClient } from '@wallet/provider'

const client = createBackendClient({
	baseURL: 'https://api.example.com',
	tenantSlug: 'synoptic',
	applicationId: 'app-key',
	translate: (key, fallback) => i18n.t(key) || fallback,
	getIid: () => iid,
	onBootstrap: (data) => dispatch(setBootstrap(data)),
	onCurrentUser: (data) => dispatch(setUser(data)),
})
```

The client automatically:

- Attaches `Authorization: Bearer <token>` on every request
- Attaches `X-Installation-Id`, `X-Application-ID`, `X-Tenant-Slug` headers
- Rotates tokens proactively (30s before expiry)
- Deduplicates concurrent refresh requests
- Handles FormData (strips Content-Type)
- Normalizes API errors (HTML detection, nested error extraction, i18n fallbacks)
- Resolves locale / timezone from `Intl`

## Auth Workflows

### `useAuth(opts?)`

`useAuth()` is the preferred API for app auth screens and app-shell hydration. It combines the backend client with Redux actions and storage cleanup.

```ts
const {
	isAuthenticated,
	isAuthHydrated,
	userScopeLoading,
	userAuthErrorMessage,
	hydrate,
	login,
	loginVerifyOtp,
	logout,
	iid,
	iidGet,
	iidSet,
	iidRotate,
	refreshAccessToken,
	refreshCurrentUser,
	refreshAccountContext,
	switchAccount,
	requestAccountDelete,
	confirmAccountDelete,
	clearMessages,
} = useAuth({
	onLoggedOut: () => router.replace('/login'),
	getLoginDeviceContext: () => ({ device_name: 'web' }),
})
```

Typical startup flow:

1. Call `hydrate()` once from an auth boundary or root screen.
2. If stored credentials exist, the hook refreshes tokens when needed.
3. Valid sessions fetch accounts, choose the persisted/default/first account, then fetch bootstrap data for that account.
4. Bootstrap data populates tenant, crypto, currency, dictionary, account, and user state.
5. Invalid or expired sessions clear local credentials and mark auth as hydrated.

### Login

```ts
const result = await login(username, password)

if (result.type === 'direct' && result.mustChangePassword) {
	router.push('/change-initial-password')
}

if (result.requiresOtp) {
	router.push('/login/verify')
}
```

`login()` is the single phase-one login entry point. If a persisted IID exists, it first attempts trusted-device direct login. If that fails, or if no IID exists, it rotates/creates an IID and starts the OTP flow. OTP completion still uses `loginVerifyOtp(code)`.

Use `login(username, password, { tryDirectLogin: false })` when resending an OTP challenge from the verification screen.

The hook also returns `tryDirectLogin`, which is true when the current provider state has an IID available for a direct-login attempt.

### Account Context

Use `switchAccount(account)` when an app lets the user change active group/account context. It updates the persisted selected account and refetches bootstrap with `X-Active-Group`.

Use `refreshAccountContext()` after account membership changes so Redux account state and bootstrap data are current.

## WebSocket

### `useWebSocket(opts)`

Explicit-params hook. Works on both web and React Native (`WebSocket` is global on both platforms).

```ts
import { useWebSocket } from '@wallet/provider'

const { isConnected } = useWebSocket({
	apiUrl: 'https://synoptic-api.vya.to/',
	accessToken,
	isAuthenticated: true,
	installationId: iid,
	onSessionDestroyed: () => logout(),
	onProfileSaved: () => refetchProfile(),
	onEhailingEvent: (event) => dispatch(ehailingEventReceived(event)),
})
```

Reconnects with exponential backoff (1s → 30s). Auto-tears down on deauth / unmount.

### `useWalletWebSocket(opts?)`

Convenience hook that auto-wires from `useWalletRoot()` + Redux `user` state:

```ts
import { useWalletWebSocket } from '@wallet/provider'

const { isConnected } = useWalletWebSocket({
	onSessionDestroyed: () => logout(),
})
```

Use `UseWebSocketOptions` when typing explicit low-level websocket connection options. Use `UseWalletWebSocketOptions` when typing callback-only options for the convenience hook.

### WebSocket Events

| Event             | `WsEvent.type`        | Handler              |
| ----------------- | --------------------- | -------------------- |
| Connected         | `'connected'`         | Internal             |
| Pong / keepalive  | `'pong'`              | Internal             |
| Profile saved     | `'profile_saved'`     | `onProfileSaved`     |
| Session destroyed | `'session_destroyed'` | `onSessionDestroyed` |
| Ehailing update   | `'ehailing_event'`    | `onEhailingEvent`    |

Dispatch `ehailingEventReceived(event)` to persist ehailing events in Redux (max 100 log entries).

## Hooks

### `useJWT(token)`

```ts
const jwt = useJWT(accessToken)
// { alg, typ, iat, exp, countdown, formatted, progress, valid }
```

### `isTokenExpired(token, skewSeconds?)`

```ts
if (isTokenExpired(token, 30)) refreshToken()
```

### `useDebounce(value, delay)`

```ts
const debounced = useDebounce(searchText, 300)
```

### `useCurrency(data?)`

```ts
import { useCurrency, currencies as bundledCurrencies } from '@wallet/provider'
const { currencyGet, currencyAmountToWords, options } = useCurrency(bundledCurrencies)
```

### `useCountry(data?)`

```ts
import { useCountry, countries as bundledCountries } from '@wallet/provider'
const { countries, getCountryByCode, options } = useCountry(bundledCountries)
```

### `usePassword(password, colors?)`

```ts
const { passwordStrength, isValidPassword } = usePassword(password)
// passwordStrength: { score (0-4), label, color, percentage, checks }
// colors: { error, warning, info, success, transparent }
```

### `useCrypto(data?)`

```ts
import { useCrypto, cryptos as bundledCryptos } from '@wallet/provider'
const { cryptoGet, options, active } = useCrypto(bundledCryptos)
```

### `useLanguage(data?)`

```ts
import { useLanguage, languages as bundledLanguages } from '@wallet/provider'
const { languageGet, options } = useLanguage(bundledLanguages)
```

### `useKyc()` / `computeKycFlags(input)`

```ts
const { requiresKyc, isKycBlocking, kycRedirect, kycStatus, isKycApproved, isKycPending, isKycRejected } = useKyc()
```

`useKyc()` reads tenant KYC config, current KYC profile data, user roles, and system roles from Redux. Use `computeKycFlags()` for non-React tests, route loaders, or utility code where those inputs are already available.

> **Migration debt — do not use these in new work.** `isKycBlocking` and `kycRedirect` model KYC as a whole-app wall with a route redirect behind it, which the Django backend expressed through role-scoped `kyc_required`/`kyc_blocking` settings. That model is retired. **KYC is a requirement, never a blocker:** it gates exactly four value actions, server-side, through the per-Service `WalletPolicy.requireKycFor{Transfers,Withdrawals,Payouts,Assets}` flags asserted by `be/`'s `kycStatusAssert` at execution time. Nothing else — no route, tab, screen, or capability — may be withheld over KYC status.
>
> New Parse work reads `kycStatus` from `auth_bootstrap`/`kyc_status` and presents a gate **in place, at the point of action**, with the `kyc_initialize` launch beside the explanation. `Service.kycRequired` is disclosure that lets a client offer the journey; it is not an authorization input. `useKyc`, `computeKycFlags`, `KycFlags.isKycBlocking`, and `KycFlags.kycRedirect` remain exported only for the quarantined legacy surfaces that still call them, and are removal targets. See the constitution's _KYC Is A Requirement, Never A Blocker_.

### `usePlatform()`

```ts
const platform = usePlatform() // 'web' | 'native'
```

## Storage

### Web (built-in)

`StorageAsync` uses `localStorage` automatically.

### Native

```ts
import { setStorageEngine } from '@wallet/provider'
import AsyncStorage from '@react-native-async-storage/async-storage'

setStorageEngine(AsyncStorage)
```

Call once at app startup. Without it, `StorageAsync` silently no-ops.

### API

```ts
StorageAsync.getItem<T>(key): Promise<T | undefined>
StorageAsync.setItem(key, value): Promise<boolean>
StorageAsync.removeItem(key): Promise<boolean>
StorageAsync.multiGet<T>(keys): Promise<Record<string, T | undefined>>
StorageAsync.multiRemove(keys): Promise<boolean>
```

## Utilities

| Export                                          | Description                                                                                                  |
| ----------------------------------------------- | ------------------------------------------------------------------------------------------------------------ |
| `base64Decode(value)` / `base64Encode(value)`   | Base64 helpers that work without Node `Buffer`                                                               |
| `currencyMask(value)`                           | Format a numeric value with thousands separators                                                             |
| `currencyParse(value)`                          | Parse currency-like input to a two-decimal string                                                            |
| `currencySymbol(code)`                          | Look up a currency symbol from bundled currency data                                                         |
| `dateFormat(date, style?)`                      | Format date-like values with shared display styles                                                           |
| `decodeJwtUnsafe(token)`                        | Decode JWT header + payload (no verification)                                                                |
| `formatDistance(meters)`                        | Render meters/kilometers for user display                                                                    |
| `placeEtaMinutes(distanceMeters)`               | Whole-minute travel estimate for the places-row `≈` line — wraps `travelSecondsEstimate`, 0 = render nothing |
| `getDistanceMeters(a, b)`                       | Calculate haversine distance between coordinates                                                             |
| `formatPhoneNumber(number)`                     | Format a phone number into international display format                                                      |
| `formatPhoneNumberByCode(number, countryCode)`  | Format a phone number for a country                                                                          |
| `getFileName(reference, file)`                  | Build upload filenames from file-like objects                                                                |
| `hasText(value)`                                | Type guard: non-empty trimmed string                                                                         |
| `initials(name)`                                | Build display initials from a name                                                                           |
| `isArray(value)`                                | Typed wrapper around `Array.isArray`                                                                         |
| `normalizeToken(value)`                         | Returns trimmed string or `null`                                                                             |
| `normalizeOtpCode(value)`                       | Removes whitespace from an OTP code                                                                          |
| `parseInternationalPhoneNumber(value)`          | Parse and normalize a full international phone number                                                        |
| `phoneNumberGetInternationalString(value)`      | Format a phone object into national/international strings                                                    |
| `random(length?)`                               | Short non-cryptographic random string                                                                        |
| `isObject(value)`                               | Type guard: plain object (not array, not null)                                                               |
| `maskEmail(value)` / `maskContactNumber(value)` | Privacy masking helpers for contact details                                                                  |
| `upperCase(str)` / `lowerCase(str)`             | Null-safe case converters                                                                                    |
| `resolveApiUrl(slug, environment)`              | Resolve API URL from slug/environment                                                                        |
| `resolveAuthenticationPhone(value)`             | Create backend auth phone payloads from UI input                                                             |
| `searchObject(query, objects)`                  | Filter small object arrays by query text                                                                     |
| `sleep(ms)`                                     | Promise that resolves after a delay                                                                          |
| `startCase(value)` / `toCamelCase(value)`       | Common display/string casing helpers                                                                         |
| `timeAgo(date, addSuffix?)`                     | Format dates as relative time text                                                                           |
| `toJSON(value)`                                 | JSON serialize/parse clone helper                                                                            |
| `truncate(value, limit?)`                       | Truncate text and append an ellipsis                                                                         |
| `withOpacity(color, opacity)`                   | Add alpha to hex or `rgb()` colors                                                                           |

### Map viewport (added under spec 047 / `feature/064`)

The `src/utils/mapFrame.ts` and `src/utils/mapRendererGeometry.ts` catalogue of shared Yaya map
geometry predates this table; only the exports this feature added are listed below rather than
backfilling the pre-existing set.

| Export                                            | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| ------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `MAP_SHEET_BLEED`                                 | The one named constant for how much map shows under/above the sheet — replaces the frame's inline `+24`s and home's own damping factor                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            |
| `HOME_MAP_COVER_FACTOR`                           | The rider home's live-snap damping factor, now shared rather than a local constant                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
| `MAP_CHROME_TOP_CLEARANCE`                        | Top clearance reserved for floating back/status chrome on `full`-dominance screens                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
| `MAP_EDGE_MARGIN`                                 | Edge margin contributed to camera insets outside the bottom slot                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
| `MAP_RECENTER_GAP`                                | Gap between the floating recenter control and the sheet/chrome it clears                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |
| `mapCameraInsets(spec: MapViewportSpec)`          | Derives dominance- and settled-snap-aware camera padding for a screen, replacing the frame's and home's two divergent inline implementations                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      |
| `mapRecenterBottom(sheetHeightPt, ceiling?)`      | The recenter control's bottom offset above the settled sheet height, clamped to an optional ceiling                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
| `recenterIntent(...)`                             | Route-aware recenter intent (`'fit' \| 'user' \| 'none'`) — the D1 decision of what a recenter tap should do                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      |
| `recenterCameraCommand(...)`                      | The concrete camera command (`'fit-manual' \| 'fly-user' \| 'none'`) for a recenter tap, graceful when no location fix or route exists                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            |
| `sheetHeightAtSnap(snaps, index, viewportHeight)` | Resolves a bottom sheet's pixel height at a given snap index, the shared basis for both the frame's and home's viewport tracking                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
| `mapBoundsEqual(a, b)` (`mapRendererGeometry.ts`) | Value-stable bounds comparison, exported and unit-tested. The latent re-fit loop it targets — a parent re-render handing the renderer a same-value-but-new-identity route — was actually closed by value-stable STRING-KEY serialisation instead: each renderer's own `fitKey` (`Component.mapbox.tsx`/`Component.google.tsx`, keying the imperative fit effect) and the frame's `boundsKey` (`mobile/src/__apps__/yaya/shared/map-frame.tsx`, keying the `mapRoute` `useMemo`). `mapBoundsEqual` is an available companion helper for a consumer that wants a typed comparison instead of a serialised key, currently unconsumed |

## Constants (seed data)

| Export       | Contents                                  | Size   |
| ------------ | ----------------------------------------- | ------ |
| `currencies` | 160+ currencies with translated names     | 83 KB  |
| `countries`  | 250+ countries with states, calling codes | 211 KB |
| `cryptos`    | Crypto tokens with color, permissions     | 4 KB   |
| `languages`  | Languages with RTL flags, labels          | 5 KB   |

## Backend Type Generator

Run locally in your project to generate typed API clients from your OpenAPI schema.

**Prerequisites:**

```bash
npm install -D dotenv openapi-typescript
```

**Run:**

```bash
node node_modules/@wallet/provider/scripts/generate-backend-types.mjs --out=src/
```

Or add to `package.json`:

```json
{
	"scripts": {
		"generate:backend-types": "node node_modules/@wallet/provider/scripts/generate-backend-types.mjs --out=src/"
	}
}
```

Set one of: `VITE_PUBLIC_BACKEND_API`, `NEXT_PUBLIC_BACKEND_API`, or `BACKEND_API`.

Generates: `backend-types.ts`, `backend-type-helpers.ts`, `backend-models.ts`, `backend-openapi-schema.json`.

### Generated Type Usage

Generated schema aliases in `backend-models.ts` make app payloads easier to type:

```ts
import type { Bootstrap, LoginDirectRequest, User } from './backend-models'

const payload: LoginDirectRequest = {
	username,
	password,
}

function handleBootstrap(data: Bootstrap) {
	// typed bootstrap payload
}
```

`backend-type-helpers.ts` provides typed path and operation helpers for apps that want OpenAPI-checked request descriptors:

```ts
import { buildBackendPath, createBackendRequestDescriptor } from './backend-type-helpers'

const path = buildBackendPath('/api/accounts/{id}/', {
	pathParams: { id: 'account-id' },
})

const descriptor = createBackendRequestDescriptor('/api/accounts/{id}/', 'get', {
	pathParams: { id: 'account-id' },
})
```

Do not hand-edit generated `backend-types.ts`, `backend-type-helpers.ts`, or `backend-models.ts` in consuming projects. Regenerate them from the OpenAPI schema instead.

## Native / Expo Setup Checklist

1. Install native deps:

    ```bash
    npx expo install @react-native-async-storage/async-storage expo-crypto
    ```

2. Wire storage at app entry:

    ```ts
    import { setStorageEngine } from '@wallet/provider'
    import AsyncStorage from '@react-native-async-storage/async-storage'
    setStorageEngine(AsyncStorage)
    ```

3. Pass `AsyncStorage` to the store:

    ```ts
    createWalletStore({ slug: 'synoptic', storage: AsyncStorage })
    ```

4. Inject UUID generator for IID:

    ```tsx
    import * as Crypto from 'expo-crypto'
    <WalletProvider generateUUID={() => Crypto.randomUUID()} ... />
    ```

5. (Optional) Redux Logger:
    ```bash
    npm install redux-logger @types/redux-logger
    ```

## Publishing

**This package is never published to a registry.** `package.json` carries `"private": true`
(the guard exists because this document once described a `yarn publish` to GitHub Packages, and
an agent followed it), and `publish.yml` was retired on 2026-08-13 (BACKLOG #34) — the old
workflow contradicted the never-publish rule. The entire distribution is
`yarn local-install --install`: build, `npm pack`, copy the tarball into each consumer's
`.packages/`, and `yarn add` it. Bump `version.json`-equivalent (package.json version) first —
yarn v1 caches `file:` tarballs by spec, so reusing a filename reinstalls the previous build.

```bash
# bump version first, then distribute to every consumer
yarn local-install --install
```

## License

MIT
